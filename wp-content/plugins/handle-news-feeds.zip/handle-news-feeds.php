<?php
/**
 * Plugin Name: Handle News Feeds
 * Description: Handle rss news feeds in admin panel
 * Text Domain: bdswiss-wordpress-plugin
 * Author: Filippos Irodotou
 */